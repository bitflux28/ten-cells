// Ten Cells desktop shell: the same game file as the web version, shown by the Chromium bundled in this app.
const { app, BrowserWindow, Menu, dialog, shell, net } = require('electron');
const path = require('path');
if (!app.requestSingleInstanceLock()) app.quit();
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
let win;
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({ width: 540, height: 960, minWidth: 360, minHeight: 560, backgroundColor: '#0b0a1f', title: 'Ten Cells', icon: path.join(__dirname, 'icon.ico'), autoHideMenuBar: true, show: false,
    webPreferences: { backgroundThrottling: false, spellcheck: false } });
  win.once('ready-to-show', () => win.show());
  win.webContents.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); } });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.loadFile(path.join(__dirname, 'index.html'));
});
// Once per launch, ask GitHub which app version is newest (a tiny file, nothing about you is sent). Any failure is ignored.
const newer = (a, b) => { const x = a.split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
async function checkUpdate() {
  try {
    const r = await net.fetch('https://raw.githubusercontent.com/bitflux28/ten-cells/main/downloads/app.json', { signal: AbortSignal.timeout(8000) });
    const v = (await r.json()).v;
    if (typeof v === 'string' && newer(v, app.getVersion())) {
      const { response } = await dialog.showMessageBox(win, { type: 'info', title: 'Ten Cells', message: `Ten Cells ${v} is available`, detail: `You have ${app.getVersion()}. Your save carries over.`, buttons: ['Download', 'Later'], defaultId: 0, cancelId: 1 });
      if (response === 0) shell.openExternal('https://github.com/bitflux28/ten-cells/raw/main/downloads/Ten%20Cells%20for%20Windows.zip');
    }
  } catch (e) { }
}
app.whenReady().then(() => setTimeout(checkUpdate, 4000));
app.on('window-all-closed', () => app.quit());
